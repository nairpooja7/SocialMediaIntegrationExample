Any service, aplication using Twitter4J can embed the following BSD licensed "powered by" logo. It is suggested to link the badge to "http://twitter4j.org/" without "en/".

HTML code snippets:
PNG:
- borderless
<a href="http://twitter4j.org/"><img src="./images/powered-by-twitter4j-138x30.png" border="0" width="122" height="30"></a>

- without border
<a href="http://twitter4j.org/"><img src="./images/powered-by-twitter4j-border-138x30.png" border="0" width="122" height="30"></a>


GIF:
- borderless
<a href="http://twitter4j.org/"><img src="./images/powered-by-twitter4j-138x30.gif" border="0" width="122" height="30"></a>

- with border
<a href="http://twitter4j.org/"><img src="./images/powered-by-twitter4j-border-138x30.gif" border="0" width="122" height="30"></a>

